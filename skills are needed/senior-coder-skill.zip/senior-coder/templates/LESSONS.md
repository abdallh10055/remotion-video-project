# LESSONS (agent memory)

## Core rules (distilled, keep short)
1. Run it before claiming it works.
2. Read the project's build/CI config before writing code.

## Verified facts (with source + date)
- <fact> - <URL> - <YYYY-MM-DD>

## User preferences & constraints
- <e.g. output must be a single .tsx file; language of explanations: Arabic>

## Log
### <date> <title>
- Symptom/surprise:
- Root cause:
- Rule for next time:
- Evidence:

## Scorecard
- Tasks: 0 | First-run success: 0 | Post-delivery bugs: 0
