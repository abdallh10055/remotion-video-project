#!/usr/bin/env bash
# Auto-detect and run available checks. Usage: bash check.sh [project_dir]
set -u
cd "${1:-.}" || exit 1
rc=0
run(){ echo "\$ $*"; "$@" || { echo "FAILED: $*"; rc=1; }; }
if [ -f package.json ]; then
  [ -d node_modules ] || run npm install
  if grep -q '"typescript"' package.json || [ -f tsconfig.json ]; then run npx --no-install tsc --noEmit; fi
  grep -q '"lint"' package.json && run npm run -s lint
  grep -q '"test"' package.json && run npm test --silent
  grep -q '"build"' package.json && run npm run -s build
fi
if ls ./*.py >/dev/null 2>&1 || [ -f pyproject.toml ] || [ -f requirements.txt ]; then
  run python3 -m compileall -q .
  command -v ruff >/dev/null && run ruff check .
  { [ -d tests ] || ls ./test_*.py >/dev/null 2>&1; } && command -v pytest >/dev/null && run pytest -q
fi
[ -f Cargo.toml ] && run cargo check
[ -f go.mod ] && run go vet ./...
echo; [ $rc -eq 0 ] && echo "ALL CHECKS PASSED (static). Now RUN the program on real input." || echo "SOME CHECKS FAILED"
exit $rc
