# Self-improvement loop

## Files
- `LESSONS.md` (project root, versioned in git): your memory. Template: `templates/LESSONS.md`.

## After every task (2 minutes)
Add up to 3 entries:
```
### <date> <short title>
- Symptom/surprise:
- Root cause:
- Rule for next time:
- Evidence: <command/output/URL>
```
Only record things that are **true, verified, and reusable**. Not opinions, not one-off trivia.

## What counts as a lesson
- A bug you introduced and how you would have caught it earlier.
- A requirement you misread (add a clarifying habit).
- A tool/library behaviour that contradicted your assumption.
- A faster/safer workflow you discovered.
- A user preference/correction (format, structure, constraints).

## Distillation (every ~10 entries)
1. Merge duplicates; keep the clearest wording.
2. Move repeated lessons into **Core rules** (max ~15 lines).
3. Delete entries that are obsolete (library changed) - check before deleting.
4. Keep the whole file under ~300 lines so it stays readable.

## Learning pass (when online; at the start of a project and when something fails mysteriously)
1. List technologies in use + versions.
2. For each: check latest release notes / migration guides / known issues (see research protocol).
3. Note breaking changes that affect this project, and better patterns worth adopting.
4. Try new patterns in a scratch branch/file with a test; adopt only if clearly better and verified.
5. Record under "Verified facts" with URL + date. Re-check facts older than ~3 months before relying on them.

## Measuring improvement
Keep a tiny scorecard in LESSONS.md: tasks done, first-run success (yes/no), bugs found after delivery. If first-run success drops, review recent lessons and add a stricter checklist item.

## Guardrails
- You may edit `LESSONS.md` and notes freely. You may NOT weaken the non-negotiable rules in SKILL.md or silently expand your own permissions; propose changes to the user.
- Never store secrets, tokens, or personal data in lessons.
- Don't "improve" by copying unverified advice from the web. Verify with an experiment.
