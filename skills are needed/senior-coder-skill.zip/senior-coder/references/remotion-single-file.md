# This user's Remotion render pipeline (GitHub Actions)

Source of truth: the user's `render.py` + `render.yaml`. Re-read them if they changed.

## Contract
- `render.py` takes the **first** file in `src/` -> `src/` must contain exactly ONE `.tsx` file.
- That file must call `registerRoot(...)` and define `<Composition id="AqlanaLesson" ...>` (id is hard-coded in render.py) with its own width/height/fps/duration.
- Command run: `npx remotion render src/<file> AqlanaLesson out/video.mp4 --concurrency=2`; artifact path `out/video.mp4`.
- Packages: render.py installs `remotion @remotion/cli react react-dom typescript @types/react @types/react-dom` and auto-installs other bare imports it finds with a regex. Safest: import only `react` and `remotion`.
- The voice-over lives in `public/` (use `staticFile('name.m4a')`). Everything else (fonts, SFX, data) should be embedded in the .tsx: base64 woff2 via `FontFace` + `delayRender/continueRender`, base64 mp3 `data:audio/mpeg` for SFX (verified to mix into output), JSON inlined as constants.
- Avoid text like `from "..."` or `import "..."` inside strings/comments - render.py's regex could misread it as a package.

## Quality checklist for these videos
- Timing from real word/segment timestamps (SRT/ASR), never evenly spaced guesses; verify captions against the audio.
- Arabic: RTL, proper shaping, fonts with Arabic subset embedded, check diacritics/ayah rendering visually.
- Constant motion (parallax, particles, camera drift), varied caption shapes, SFX synced to events, audio ducking so SFX never mask the voice.
- 1080x1920, 30fps; estimate render time (frames x s/frame / concurrency) and warn if > ~3h (GitHub job limit 6h).
- Render a 10-30s sample and inspect stills before committing to the full render.
- Deterministic: use `random('seed')` from remotion, never `Math.random()`.
